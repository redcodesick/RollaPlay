# Windows Media Station — Windows Validation Checklist

**Status: Not run in this workspace.** The current agent workspace is Linux and does not include Rust/Cargo, Windows, or a Xiaomi Mi Box. Record the Windows version, app commit, device model, test media characteristics, and result for every run. Do not mark a check complete from the browser preview.

Phase 4 (Google Cast / Xiaomi Mi Box) has its own hardware checklist in [docs/cast-testing.md](docs/cast-testing.md); run it together with the Phase 3 checks below.

## Test environment record

- Windows edition/build:
- CPU / RAM:
- App commit and version:
- Filesystem(s) tested (NTFS / removable / network):
- Test folder and sample file formats:
- Windows account privilege level:
- Date / tester:

## Automated test platform split

### Cross-platform Rust unit tests

Run with Rust/Cargo and the native prerequisites for the selected Tauri target (Linux also needs the Tauri WebKitGTK development packages). These tests use temporary directories and SQLite; they do **not** exercise COM or actual Windows thumbnail providers. They have not been executed in this workspace because Cargo is unavailable.

- [ ] Cache filename path-traversal rejection and orphan/temp-file cleanup.
- [ ] Legacy SQLite migration creates availability and thumbnail-cache metadata.
- [ ] Repeated scans do not create duplicate media rows.
- [ ] File size/modification changes preserve the media ID and invalidate its thumbnail metadata.
- [ ] Unique rename detection preserves playlist-item references.
- [ ] Pre-cancelled scans do not commit partial index changes.
- [ ] Duplicate active scans for the same directory are rejected.
- [ ] Missing-root handling marks entries temporarily unavailable and preserves playlists.
- [ ] A completed scan marks confirmed deletions permanently missing without deleting playlist rows.
- [ ] Removing a library folder marks it removed without deleting playlist rows.
- [ ] Partial/inaccessible scans classify unobserved entries as temporary rather than permanently missing.

### Cross-platform HTTP/network unit tests

These are independent of the React UI and use an in-process Axum router, temporary files, SQLite, and a loopback `ConnectInfo` value. They run wherever the Rust/Tauri target prerequisites are installed.

- [ ] Full GET and HEAD response headers/body.
- [ ] Closed, single-byte, open-ended, and suffix byte ranges with 206 and exact Content-Range.
- [ ] Invalid, out-of-bounds, and multiple-range requests return 416 with `bytes */size` (multi-range is intentionally unsupported).
- [ ] Unauthorized requests, invalid media IDs, missing files, and paths outside the registered root are rejected.
- [ ] MIME sniffing takes precedence when recognizable; extension fallback is marked in the response header.
- [ ] Large body streaming, concurrent independent readers, and an interrupted body clean up active-stream diagnostics.
- [ ] Loopback-only CORS preflight and no HTTP administrative routes.
- [ ] Private IPv4 selection policy and port fallback when the configured port is occupied.

### Windows-only checks

- [ ] Build and launch the Tauri desktop app separately on Windows 10 and Windows 11.
- [ ] Select a local folder and a removable USB folder using the native directory picker.
- [ ] Recursively scan MP4, MKV, AVI, MOV, WMV, WebM, MPEG/MPG, M4V, and 3GP sample files.
- [ ] Verify the library shows actual file names, sizes, paths, and extensions; verify no file bytes are read into the UI.
- [ ] Verify `IShellItemImageFactory` extracts thumbnails for formats with an installed Windows Shell thumbnail provider.
- [ ] Verify provider-unsupported and corrupt files show the generic thumbnail, a visible error, and a working retry action.
- [ ] Verify changing size/quality settings creates a new cache variant and old cache files are cleaned up.
- [ ] Verify thumbnails persist after application restart and remain under LocalAppData rather than the install directory or SQLite database.
- [ ] Modify a video while retaining its path; rescan and verify metadata updates and the thumbnail is regenerated.
- [ ] Rename a video without changing size/mtime; rescan and verify the existing media ID and playlist reference follow the renamed path when the match is unique.
- [ ] Cancel a large scan; verify the UI responds, the scan stops, and no partial index update is committed.
- [ ] Start the same directory scan twice; verify the second request is rejected and only one scan runs.
- [ ] Remove a folder from the library; verify no physical video is deleted and playlist rows remain.
- [ ] Delete a file and perform a complete scan; verify it is marked permanently missing while playlist references remain.
- [ ] Unplug a USB drive during or between scans; verify the folder/files are temporarily unavailable, not permanently missing, and playlist rows remain.
- [ ] Reconnect the USB drive and rescan; verify available files return and unchanged thumbnails are reused.
- [ ] Restrict folder permissions and rescan; verify inaccessible paths are reported and not treated as confirmed deletions.
- [ ] Restart the app after cancelling or forcibly closing during scan; verify database integrity and that a fresh scan can start.

### Phase 3 media server checks

- [ ] Confirm the default listener uses port 8765 and binds to the selected private LAN IPv4 only, not `0.0.0.0` or a public interface.
- [ ] Test adapter selection with Wi-Fi, Ethernet, VPN/virtual, loopback, down, and multiple active adapters; confirm the default-route physical private interface wins.
- [ ] Occupy the configured port; verify fallback selection and the actual port shown in Settings. Configure a new port and restart.
- [ ] Reveal/copy the pairing token in the local Settings UI, then from a second LAN device request a registered media ID with `Authorization: Bearer …`; verify full GET, HEAD, byte ranges, 206, and 416 headers.
- [ ] Confirm token disclosure requires a local Tauri action, tokens are absent from diagnostics, and missing/invalid tokens, unknown IDs, removed/unavailable files, and paths outside the approved root cannot stream.
- [ ] Verify Windows DPAPI user-scope token survives restart, is not stored as plaintext, and cannot be decrypted under another Windows user.
- [ ] Verify MIME detection for representative MP4/MKV/AVI/MOV/WMV/WebM/MPEG/M4V/3GP files; check the extension-fallback marker for unrecognized containers.
- [ ] Stream a large file while seeking; unplug its USB drive mid-transfer and confirm the request ends cleanly, diagnostics mark interruption, and playlist/library state is retained.
- [ ] Run concurrent clients; confirm bytes, client addresses, durations, request states, and active stream counts remain independent and logs contain no bearer token.
- [ ] Clear request diagnostics and verify active streams are not terminated.
- [ ] Stop, start, and restart the server from Settings; close the app during a transfer and verify bounded graceful shutdown.
- [ ] Change Wi-Fi networks or renew the DHCP lease; confirm interface/IP changes are detected, the listener rebinds, status events update Settings, and the old endpoint is not shown as current.
- [ ] Verify Windows Firewall behavior from another LAN device and document the required private-network allow rule. The local connection test alone does not prove inbound firewall acceptance.
- [ ] Confirm `/api/status` and other management routes are not served over HTTP; server/network controls are available only through Tauri commands.
- [ ] Confirm a token-authenticated health probe works, an unauthenticated LAN request is rejected, and clients outside the selected private subnet are rejected.
- [ ] Confirm CORS preflight is accepted for loopback/Tauri localhost origins and denied for an arbitrary website origin.
- [ ] Verify server status distinguishes starting, running, stopped, network unavailable, port conflict, and error states without showing a stale IP.

## Run notes

For each item, record **Pass / Fail / Blocked**, steps and expected/actual result, relevant logs, and a screenshot or database query when useful. A blocked test is not a pass. Run on real Windows Shell providers; do not substitute a simulated thumbnail provider.
