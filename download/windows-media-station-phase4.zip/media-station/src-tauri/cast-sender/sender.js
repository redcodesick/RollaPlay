/* Windows Media Station — managed Cast sender page.
 *
 * Runs in a Chrome application-mode window served from http://127.0.0.1, a
 * secure context accepted by the official Google Cast Web Sender SDK.
 * Commands arrive over Server-Sent Events from the desktop app; playback
 * status comes exclusively from cast.framework RemotePlayer events — the
 * page never simulates progress with timers, never renders the streaming
 * URL (which embeds a short-lived credential), and never persists anything.
 */
(() => {
  'use strict';

  /* Registered synchronously so the official framework script — which runs
   * next — always finds the availability hook in place. */
  let frameworkAvailability = null;
  let domReady = false;

  window.__onGCastApiAvailable = function (available) {
    frameworkAvailability = available;
    tryInitFramework();
  };

  document.addEventListener('DOMContentLoaded', () => {
    domReady = true;
    gatherElements();
    startEventSource();
    bindLocalControls();
    post({ type: 'sender_ready' });
    if (frameworkAvailability === null) setFrameworkStatus('Waiting for the Cast framework');
    tryInitFramework();
  });

  const elements = {};
  const elementIds = [
    'headline', 'cast-dot', 'cast-state-text', 'session-dot', 'session-state-text',
    'pick-device', 'device-name', 'framework-state', 'now-playing', 'media-title',
    'seek', 'time-current', 'time-total', 'play-pause', 'stop', 'mute', 'disconnect',
    'volume', 'status-message',
  ];

  function gatherElements() {
    elementIds.forEach((id) => {
      elements[id] = document.getElementById(id);
    });
  }

  let frameworkReady = false;
  let context = null;
  let player = null;
  let controller = null;
  let seeking = false;
  let lastStatusPost = 0;
  let currentTitle = null;

  const castStateLabels = {
    NO_DEVICES_AVAILABLE: 'No Cast devices found on this network yet',
    NOT_CONNECTED: 'Cast devices available — not connected',
    CONNECTING: 'Connecting…',
    CONNECTED: 'Connected to a Cast device',
  };

  const sessionStateLabels = {
    SESSION_STATE_NO_DEVICES_AVAILABLE: 'No devices available',
    SESSION_STATE_STARTING: 'Starting session…',
    SESSION_STATE_STARTED: 'Session active',
    SESSION_STATE_RESUMED: 'Session restored',
    SESSION_STATE_ENDING: 'Ending session…',
    SESSION_STATE_ENDED: 'Session ended',
    SESSION_STATE_STOPPED: 'Session stopped',
  };

  function post(payload) {
    try {
      const body = JSON.stringify(payload);
      if (body.length > 12000) return;
      fetch('/playback-event', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body,
      }).catch(() => {});
    } catch (_) {
      /* the bridge will surface the missing connection */
    }
  }

  function clampText(value, max) {
    return typeof value === 'string' ? value.slice(0, max) : undefined;
  }

  function setStatus(message, isError) {
    if (!elements['status-message']) return;
    elements['status-message'].textContent = message;
    elements['status-message'].className = isError ? 'message error' : 'message info';
  }

  function setFrameworkStatus(text) {
    if (elements['framework-state']) elements['framework-state'].textContent = text;
  }

  function setDot(id, tone) {
    if (elements[id]) elements[id].className = 'dot' + (tone ? ' ' + tone : '');
  }

  function formatTime(seconds) {
    const value = Number.isFinite(seconds) && seconds > 0 ? Math.floor(seconds) : 0;
    const hours = Math.floor(value / 3600);
    const minutes = Math.floor((value % 3600) / 60);
    const rest = value % 60;
    const pad = (n) => String(n).padStart(2, '0');
    return hours > 0 ? `${hours}:${pad(minutes)}:${pad(rest)}` : `${minutes}:${pad(rest)}`;
  }

  function deviceName() {
    try {
      const session = context && context.getCurrentSession();
      const device = session && typeof session.getCastDevice === 'function' ? session.getCastDevice() : null;
      return (device && device.friendlyName) || 'Cast device';
    } catch (_) {
      return 'Cast device';
    }
  }

  function tryInitFramework() {
    if (frameworkAvailability === null || !domReady || frameworkReady) return;
    if (!frameworkAvailability || !window.cast || !window.chrome || !window.chrome.cast || !window.chrome.cast.media) {
      frameworkAvailability = null;
      setFrameworkStatus('Cast framework unavailable');
      setDot('cast-dot', 'bad');
      if (elements['cast-state-text']) elements['cast-state-text'].textContent = 'The Google Cast framework failed to load';
      setStatus('The Google Cast framework could not load in this window. Check the internet connection of this PC, then relaunch the sender from the desktop app.', true);
      post({ type: 'sender_error', message: 'The Google Cast framework could not load.' });
      return;
    }
    try {
      initFramework();
    } catch (error) {
      setStatus('Cast initialization failed: ' + (error && error.message ? error.message : String(error)), true);
      post({ type: 'sender_error', message: clampText('Cast initialization failed: ' + String(error), 380) });
    }
  }

  function initFramework() {
    frameworkReady = true;
    context = cast.framework.CastContext.getInstance();
    context.setOptions({
      receiverApplicationId: chrome.cast.media.DEFAULT_MEDIA_RECEIVER_APP_ID,
      autoJoinPolicy: chrome.cast.AutoJoinPolicy.ORIGIN_SCOPED,
      defaultActionPolicy: chrome.cast.DefaultActionPolicy.CREATE_SESSION_ONCE,
    });
    context.addEventListener(cast.framework.CastContextEventType.CAST_STATE_CHANGED, onCastStateChanged);
    context.addEventListener(cast.framework.CastContextEventType.SESSION_STATE_CHANGED, onSessionStateChanged);

    player = new cast.framework.RemotePlayer();
    controller = new cast.framework.RemotePlayerController(player);
    [
      cast.framework.RemotePlayerEventType.IS_CONNECTED_CHANGED,
      cast.framework.RemotePlayerEventType.PLAYER_STATE_CHANGED,
      cast.framework.RemotePlayerEventType.CURRENT_TIME_CHANGED,
      cast.framework.RemotePlayerEventType.DURATION_CHANGED,
      cast.framework.RemotePlayerEventType.VOLUME_LEVEL_CHANGED,
      cast.framework.RemotePlayerEventType.IS_MUTED_CHANGED,
      cast.framework.RemotePlayerEventType.IS_MEDIA_LOADED_CHANGED,
    ].forEach((type) => controller.addEventListener(type, onRemotePlayerEvent));

    setFrameworkStatus('Official Cast sender SDK ready');
    if (context.getCurrentSession()) {
      elements['device-name'].textContent = deviceName();
    }
    onCastStateChanged();
    onSessionStateChanged({ sessionState: context.getSessionState() });
    renderMedia();
    postStatus(true);
  }

  function onCastStateChanged() {
    if (!context || !elements['cast-state-text']) return;
    const state = context.getCastState();
    const label = castStateLabels[state] || state || 'Unknown';
    elements['cast-state-text'].textContent = label;
    elements['pick-device'].disabled = !frameworkReady || state === 'NO_DEVICES_AVAILABLE';
    setDot('cast-dot', state === 'CONNECTED' ? 'ok' : state === 'NO_DEVICES_AVAILABLE' ? 'bad' : state === 'CONNECTING' ? 'warn' : '');
    elements['headline'].textContent = state === 'CONNECTED' ? 'Casting to ' + deviceName() : 'Choose a Cast device';
    post({ type: 'cast_state', state: clampText(state, 40) });
  }

  function onSessionStateChanged(event) {
    if (!context || !elements['session-state-text']) return;
    const sessionState = (event && event.sessionState) || context.getSessionState();
    const label = sessionStateLabels[sessionState] || sessionState || 'Unknown';
    elements['session-state-text'].textContent = label;
    const active = sessionState === 'SESSION_STATE_STARTED' || sessionState === 'SESSION_STATE_RESUMED';
    setDot('session-dot', active ? 'ok' : sessionState === 'SESSION_STATE_STARTING' || sessionState === 'SESSION_STATE_ENDING' ? 'warn' : '');
    if (sessionState === 'SESSION_STATE_STARTED') {
      elements['device-name'].textContent = deviceName();
      post({ type: 'session_started', device_name: clampText(deviceName(), 120), session_state: clampText(sessionState, 40) });
    } else if (sessionState === 'SESSION_STATE_RESUMED') {
      elements['device-name'].textContent = deviceName();
      post({ type: 'session_resumed', device_name: clampText(deviceName(), 120), session_state: clampText(sessionState, 40) });
    } else if (sessionState === 'SESSION_STATE_ENDED' || sessionState === 'SESSION_STATE_STOPPED') {
      elements['device-name'].textContent = 'None';
      elements['now-playing'].hidden = true;
      post({ type: 'session_ended', session_state: clampText(sessionState, 40) });
    }
  }

  function postStatus(force) {
    if (!frameworkReady || !controller) return;
    const now = Date.now();
    if (!force && now - lastStatusPost < 900) return;
    lastStatusPost = now;
    if (!player || !player.isConnected) {
      post({ type: 'media_status', player_state: 'IDLE', position_seconds: 0, duration_seconds: 0 });
      return;
    }
    post({
      type: 'media_status',
      player_state: clampText(player.playerState, 30) || 'IDLE',
      position_seconds: Number.isFinite(player.currentTime) ? player.currentTime : 0,
      duration_seconds: Number.isFinite(player.duration) ? player.duration : 0,
      volume_level: Number.isFinite(player.volumeLevel) ? player.volumeLevel : 1,
      muted: !!player.isMuted,
    });
  }

  function renderMedia() {
    if (!elements['now-playing']) return;
    if (!player || !player.isConnected) {
      elements['now-playing'].hidden = true;
      return;
    }
    elements['now-playing'].hidden = false;
    const title = (typeof player.title === 'string' && player.title) || currentTitle || 'Video';
    elements['media-title'].textContent = title;
    const duration = Number.isFinite(player.duration) && player.duration > 0 ? player.duration : 0;
    const position = Number.isFinite(player.currentTime) ? player.currentTime : 0;
    if (!seeking) {
      elements.seek.max = String(Math.max(1, Math.round(duration * 1000)));
      elements.seek.value = String(Math.max(0, Math.round(position * 1000)));
    }
    elements['time-current'].textContent = formatTime(position);
    elements['time-total'].textContent = duration ? formatTime(duration) : '--:--';
    if (Number.isFinite(player.volumeLevel)) elements.volume.value = String(player.volumeLevel);
    elements.mute.textContent = player.isMuted ? 'Unmute' : 'Mute';
    elements['play-pause'].textContent = player.playerState === 'PLAYING' ? 'Pause' : 'Play';
  }

  function onRemotePlayerEvent() {
    renderMedia();
    postStatus(false);
  }

  /* Only LAN streaming URLs carrying a scoped grant may reach the receiver.
   * localhost, file://, and blob: URLs are rejected outright. */
  const RECEIVER_URL_PATTERN = /^http:\/\/(192\.168\.\d+\.\d+|10\.\d+\.\d+\.\d+|172\.(1[6-9]|2\d|3[01])\.\d+\.\d+):\d+\/media\/\d+\?cast_token=[A-Za-z0-9_-]+$/;

  function friendlyLoadError(error) {
    const code = error && (error.description || error.code);
    switch (code) {
      case 'LOAD_CANCELLED': return 'Loading was cancelled on the receiver.';
      case 'LOAD_TIMEOUT': return 'The receiver did not fetch the video in time. Check Wi-Fi and the Windows firewall.';
      case 'LOAD_FAILED': return 'The receiver could not load the video. The format must be MP4/M4V/WebM/MKV with H.264, VP8, or VP9 video and AAC audio.';
      case 'SESSION_ERROR': return 'The Cast session reported an error while loading.';
      default: return 'The receiver could not play this video (' + String(code || 'unknown error') + ').';
    }
  }

  function loadMedia(command) {
    if (!frameworkReady || !context) {
      post({ type: 'sender_error', message: 'The Cast framework is not ready yet. Try again in a moment.' });
      return;
    }
    const session = context.getCurrentSession();
    if (!session) {
      post({ type: 'sender_error', message: 'Cast session unavailable — choose a Cast device first.' });
      setStatus('Cast session unavailable — choose a Cast device first.', true);
      return;
    }
    if (typeof command.url !== 'string' || !RECEIVER_URL_PATTERN.test(command.url)) {
      post({ type: 'sender_error', message: 'The desktop app supplied a URL this receiver cannot fetch.' });
      return;
    }
    currentTitle = clampText(command.title, 160) || 'Video';
    try {
      const mediaInfo = new chrome.cast.media.MediaInfo(command.url, clampText(command.mime_type, 80) || 'video/mp4');
      const metadata = new chrome.cast.media.MovieMediaMetadata();
      metadata.title = currentTitle;
      mediaInfo.metadata = metadata;
      const request = new chrome.cast.media.LoadRequest(mediaInfo);
      request.currentTime = Number.isFinite(command.position_seconds) && command.position_seconds > 0 ? command.position_seconds : 0;
      session.loadMedia(request)
        .then(() => {
          elements['media-title'].textContent = currentTitle;
          elements['now-playing'].hidden = false;
          setStatus('Playing on ' + deviceName() + '. Control playback from Windows Media Station.', false);
          post({ type: 'media_loaded' });
          postStatus(true);
        })
        .catch((error) => {
          const message = friendlyLoadError(error);
          setStatus(message, true);
          post({
            type: 'load_failed',
            error_code: clampText(error && (error.description || error.code), 60),
            message,
          });
        });
    } catch (error) {
      setStatus('Loading failed: ' + (error && error.message ? error.message : String(error)), true);
      post({ type: 'load_failed', error_code: 'LOAD_EXCEPTION', message: clampText(String(error), 380) });
    }
  }

  function applyControl(command) {
    const action = command && command.action;
    if (action === 'close_sender') {
      window.close();
      return;
    }
    if (action === 'disconnect') {
      if (context) context.endCurrentSession(true);
      return;
    }
    if (!controller || !player || !player.isConnected) {
      if (action === 'stop') {
        post({ type: 'media_status', player_state: 'IDLE', position_seconds: 0, duration_seconds: 0 });
      }
      return;
    }
    try {
      switch (action) {
        case 'play':
          if (player.playerState === 'PAUSED' || player.playerState === 'BUFFERING') controller.playOrPause();
          break;
        case 'pause':
          if (player.playerState === 'PLAYING') controller.playOrPause();
          break;
        case 'toggle_play':
          controller.playOrPause();
          break;
        case 'stop':
          controller.stop();
          break;
        case 'seek':
          if (Number.isFinite(command.position_seconds) && Number.isFinite(player.duration)) {
            player.currentTime = Math.min(Math.max(0, command.position_seconds), Math.max(0, player.duration));
            controller.seek();
          }
          break;
        case 'set_volume':
          if (Number.isFinite(command.volume)) controller.setVolumeLevel(Math.min(1, Math.max(0, command.volume)));
          break;
        case 'set_mute':
          if (!!player.isMuted !== !!command.muted) controller.muteOrUnmute();
          break;
        default:
          break;
      }
    } catch (error) {
      post({ type: 'sender_error', message: clampText('Control "' + action + '" failed: ' + String(error), 380) });
    }
    setTimeout(() => {
      renderMedia();
      postStatus(true);
    }, 150);
  }

  function handleCommand(command) {
    if (!command || typeof command !== 'object') return;
    switch (command.type) {
      case 'hello':
        if (command.playback && command.playback.filename && !currentTitle) {
          elements['media-title'].textContent = String(command.playback.filename).slice(0, 160);
        }
        break;
      case 'load_media':
        loadMedia(command);
        break;
      case 'control':
        applyControl(command);
        break;
      default:
        break;
    }
  }

  function startEventSource() {
    const source = new EventSource('/events');
    source.onmessage = (event) => {
      let command;
      try {
        command = JSON.parse(event.data);
      } catch (_) {
        return;
      }
      handleCommand(command);
    };
    source.onerror = () => {
      /* EventSource reconnects automatically; the bridge tracks connection counts */
    };
    return source;
  }

  function bindLocalControls() {
    elements['pick-device'].addEventListener('click', () => {
      if (!context) return;
      context.requestSession().catch((error) => {
        const code = error && error.code;
        if (code !== 'cancel') {
          setStatus('Could not open the device picker (' + String(code || error) + ').', true);
        }
      });
    });
    elements['play-pause'].addEventListener('click', () => applyControl({ type: 'control', action: 'toggle_play' }));
    elements.stop.addEventListener('click', () => applyControl({ type: 'control', action: 'stop' }));
    elements.mute.addEventListener('click', () => applyControl({ type: 'control', action: 'set_mute', muted: !(player && player.isMuted) }));
    elements.disconnect.addEventListener('click', () => applyControl({ type: 'control', action: 'disconnect' }));
    elements.seek.addEventListener('input', () => {
      seeking = true;
      const duration = player && Number.isFinite(player.duration) ? player.duration : 0;
      elements['time-current'].textContent = formatTime((Number(elements.seek.value) / 1000) * duration);
    });
    elements.seek.addEventListener('change', () => {
      const duration = player && Number.isFinite(player.duration) ? player.duration : 0;
      seeking = false;
      applyControl({ type: 'control', action: 'seek', position_seconds: (Number(elements.seek.value) / 1000) * duration });
    });
    elements.volume.addEventListener('change', () => {
      applyControl({ type: 'control', action: 'set_volume', volume: Number(elements.volume.value) });
    });
  }
})();
