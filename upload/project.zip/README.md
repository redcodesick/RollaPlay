# Windows Media Station

Windows Media Station is a local-first Tauri 2 desktop app for organizing video files on a Windows PC. The React/Vite interface is the controller; Rust owns directory access, indexing, SQLite persistence, and thumbnail work. The browser preview intentionally does not simulate Windows filesystem access or Cast behavior.

## Architecture

- **Desktop UI:** React, TypeScript, Vite, Lucide, dark media-center layout.
- **Native backend:** Tauri 2 commands, SQLite in the app-local data directory, and Tokio-backed blocking tasks for filesystem scans and Windows Shell work.
- **Media indexing:** recursive, non-symlink-following scans of approved folders. Paths, sizes, and high-resolution modification timestamps drive incremental updates. Folder removal and missing files never delete physical media or playlist references.
- **Thumbnail engine:** Windows `IShellItemImageFactory::GetImage` with `SIIGBF_THUMBNAILONLY`. COM and Shell extraction run away from the UI thread. Generated JPEGs are in `$LOCALAPPDATA/<app-identifier>/thumbnails`; SQLite stores source metadata, cache path, dimensions, quality, status, and errors—not image bytes. Unsupported or unavailable Shell thumbnail providers yield a generic card and an actionable error.
- **Embedded HTTP media server:** Axum/Tokio binds only to a selected active RFC1918 IPv4 adapter, defaults to port 8765, and tries a fallback port range on conflicts. `GET`/`HEAD /media/{media_id}` resolves only indexed files and streams them in chunks with single-range 206 and invalid-range 416 handling; multipart ranges are deliberately rejected with 416. Canonical-root checks and capability-relative file opening protect approved directories; MIME is signature-first with a safe extension fallback. Requests require a bearer token; Windows persists it encrypted with user-scoped DPAPI. The token is revealable/copyable only through the local Tauri Settings view for deliberate pairing with a trusted device, and is never included in diagnostics. Local-origin-only CORS is enabled for media requests. Status/settings are Tauri commands rather than LAN admin routes; `/health` is token-protected.
- **Direct play only:** no FFmpeg, transcoding, remuxing, or external thumbnail service is included. Google Cast is a future phase and is not simulated.

## Thumbnail defaults

The default grid preview is 320 × 180 at JPEG quality 82. The library screen offers small, medium, and large presets and three quality levels. Cache entries are invalidated when indexed file size or modification timestamp changes. A refresh action retries failed extractions; cache cleanup removes orphaned and interrupted temporary files.

## Data and availability

SQLite migrations add explicit media and directory availability states:

- `available` — visible in the library.
- `temporarily_unavailable` — drive/root disappeared or could not be read; file and playlist rows are retained.
- `partially_unavailable` — a scan encountered inaccessible paths; unobserved files are not declared permanently missing.
- `permanently_missing` — a complete scan confirmed a file is absent.
- `removed_from_library` — the user removed the folder; physical files and playlist rows remain untouched.

A scan is transactional. Cancelling or interrupting it before commit discards partial index changes. Duplicate concurrent scans of the same folder are rejected. Unique path/size/modified-time matches are used to recognize likely renames while avoiding ambiguous matches.

## Development and tests

The frontend preview and production bundle use the project’s pnpm scripts. Rust tests are defined in `src-tauri/src/lib.rs`, `src-tauri/src/media_server.rs`, `src-tauri/src/network.rs`, `src-tauri/src/secret.rs`, and `src-tauri/src/thumbnail.rs`; run them with `cargo test --manifest-path src-tauri/Cargo.toml`. The native Windows Shell thumbnail test is ignored unless a sample video is supplied through `WMS_TEST_VIDEO`, and can be enabled on Windows with `cargo test --manifest-path src-tauri/Cargo.toml windows_shell_extracts_and_encodes_a_video_thumbnail -- --ignored`.

The native Windows Shell thumbnail provider can only be exercised on Windows.

- Cross-platform Rust unit tests cover cache safety/invalidation, migrations, scan cancellation/duplicates, rename and availability behavior, playlist preservation, full/HEAD/range streaming, auth/path checks, MIME fallback, large/concurrent/interrupted streams, local CORS, and port fallback.
- Windows-only manual checks are listed in [docs/windows-validation.md](docs/windows-validation.md).
- The Linux browser preview can verify UI layout and interactions only. Folder scanning, Tauri commands, Windows Shell extraction, drive unplug behavior, and installer behavior require the native desktop app.

## Current phase status

Phase 3 implementation, independent HTTP tests, and Windows validation steps are present in the source tree. The frontend build has been verified; Rust tests/build and real Windows behavior have not been run in this Linux workspace. Do not treat the checklist or Rust tests as passed until they are executed and recorded. Google Cast and final Windows installer validation remain out of scope for this phase.
