import { useEffect, useMemo, useState } from 'react'
import useSWR from 'swr'
import { listen } from '@tauri-apps/api/event'
import { convertFileSrc, invoke } from '@tauri-apps/api/core'
import { open } from '@tauri-apps/plugin-dialog'
import {
  AlertCircle, Check, Film, FolderOpen, FolderPlus, HardDrive, LoaderCircle,
  RefreshCw, ShieldCheck, Trash2, X,
} from 'lucide-react'
import {
  getMediaDirectories, getMediaFiles, getThumbnailSettings, isDesktopApp,
  type CacheCleanupResult, type MediaDirectory, type MediaFile, type ScanProgress,
  type ScanResult, type ThumbnailProgress, type ThumbnailSettings,
} from '../media'

const extensions = ['mp4', 'mkv', 'avi', 'mov', 'wmv', 'webm', 'mpeg', 'mpg', 'm4v', '3gp']
type SortBy = 'name' | 'date' | 'size'

function formatBytes(value: number) {
  if (value < 1024) return `${value} B`
  const units = ['KB', 'MB', 'GB', 'TB']
  let amount = value / 1024
  let unit = 0
  while (amount >= 1024 && unit < units.length - 1) {
    amount /= 1024
    unit += 1
  }
  return `${amount.toFixed(amount >= 100 ? 0 : 1)} ${units[unit]}`
}

function folderForPath(path: string) {
  const separator = Math.max(path.lastIndexOf('/'), path.lastIndexOf('\\'))
  return separator > 0 ? path.slice(0, separator) : path
}

function MediaCard({ media, onRefresh }: { media: MediaFile; onRefresh: (media: MediaFile) => Promise<void> }) {
  const [imageFailed, setImageFailed] = useState(false)
  const [isRefreshing, setIsRefreshing] = useState(false)
  const thumbnailUrl = media.thumbnail_path ? convertFileSrc(media.thumbnail_path) : null
  const showThumbnail = media.thumbnail_status === 'ready' && thumbnailUrl && !imageFailed

  useEffect(() => setImageFailed(false), [thumbnailUrl])

  async function refresh() {
    setIsRefreshing(true)
    try {
      await onRefresh(media)
    } finally {
      setIsRefreshing(false)
    }
  }

  return (
    <article className={`media-card poster-${media.extension}`}>
      <div className="media-artwork">
        {showThumbnail ? <img className="media-thumbnail" src={thumbnailUrl} alt="" onError={() => setImageFailed(true)} /> : <div className="media-placeholder" aria-label="Generic video thumbnail">
          <span className="artwork-orbit" />
          <span className="artwork-glow" />
          <Film size={27} strokeWidth={1.35} />
          {media.thumbnail_status === 'pending' && <span className="thumbnail-state" role="status"><LoaderCircle size={13} className="spin-icon" />Generating preview</span>}
          {(media.thumbnail_status === 'failed' || imageFailed) && <span className="thumbnail-state failed" title={media.thumbnail_error ?? 'Thumbnail extraction failed'} role="status">Preview unavailable</span>}
        </div>}
        <span className="media-extension">{media.extension.toUpperCase()}</span>
        <button className="thumbnail-refresh" onClick={refresh} disabled={isRefreshing} aria-label={`Regenerate thumbnail for ${media.filename}`} title={media.thumbnail_error ?? 'Regenerate thumbnail'}>
          {isRefreshing ? <LoaderCircle size={15} className="spin-icon" /> : <RefreshCw size={15} />}
        </button>
      </div>
      <div className="media-card-info">
        <h3 title={media.filename}>{media.filename}</h3>
        <div className="media-card-meta"><span>{media.extension.toUpperCase()}</span><i />{formatBytes(media.size_bytes)}</div>
        <p title={folderForPath(media.path)}>{folderForPath(media.path)}</p>
        {media.thumbnail_status === 'failed' && media.thumbnail_error && <small className="thumbnail-error-text" title={media.thumbnail_error}>{media.thumbnail_error}</small>}
      </div>
    </article>
  )
}

function FolderRow({
  directory, progress, onScan, onCancel, onRemove,
}: {
  directory: MediaDirectory
  progress?: ScanProgress
  onScan: (directory: MediaDirectory) => void
  onCancel: (directory: MediaDirectory) => void
  onRemove: (directory: MediaDirectory) => void
}) {
  const scanning = progress?.phase === 'scanning'
  const folderStatus = directory.availability_state === 'temporarily_unavailable'
    ? 'Drive or folder unavailable · indexed items and playlists are retained'
    : directory.availability_state === 'partially_unavailable'
      ? 'Some locations inaccessible · previous entries were preserved'
      : directory.last_scanned_at
      ? `Last scanned ${new Date(`${directory.last_scanned_at.replace(' ', 'T')}Z`).toLocaleString()}`
      : 'Not scanned yet'
  return (
    <div className={`library-folder-row ${directory.availability_state !== 'available' ? 'folder-offline' : ''}`}>
      <span className="folder-row-icon"><FolderOpen size={17} /></span>
      <span className="folder-row-info"><strong title={directory.path}>{directory.path}</strong><small>{scanning ? `Scanning · ${progress.files_found} videos found · ${progress.inaccessible_entries} inaccessible items` : folderStatus}</small></span>
      {scanning ? <><span className="folder-scanning"><LoaderCircle size={15} /> Scanning</span><button className="folder-cancel" onClick={() => onCancel(directory)} aria-label={`Cancel scan of ${directory.path}`}><X size={15} /> Cancel</button></> : <button className="folder-action" onClick={() => onScan(directory)} aria-label={`${directory.availability_state !== 'available' ? 'Retry scan' : 'Rescan'} ${directory.path}`}><RefreshCw size={15} /> {directory.availability_state !== 'available' ? 'Retry' : 'Scan'}</button>}
      <button className="folder-remove" onClick={() => onRemove(directory)} disabled={scanning} aria-label={`Remove ${directory.path} from library`}><Trash2 size={15} /></button>
    </div>
  )
}

export default function MediaLibrary({ searchQuery }: { searchQuery: string }) {
  const [extension, setExtension] = useState('')
  const [sortBy, setSortBy] = useState<SortBy>('name')
  const [scanProgress, setScanProgress] = useState<Record<number, ScanProgress>>({})
  const [isAdding, setIsAdding] = useState(false)
  const [notice, setNotice] = useState('')
  const [errorMessage, setErrorMessage] = useState('')
  const isDesktop = isDesktopApp()
  const search = searchQuery.trim()
  const fileKey = useMemo(() => ['media-files', search, extension, sortBy] as const, [search, extension, sortBy])
  const { data: files = [], isLoading: isLoadingFiles, error: filesError, mutate: refreshFiles } = useSWR(fileKey, getMediaFiles)
  const { data: directories = [], isLoading: isLoadingDirectories, mutate: refreshDirectories } = useSWR('media-directories', getMediaDirectories)
  const { data: thumbnailSettings = { width: 320, height: 180, quality: 82 }, mutate: refreshThumbnailSettings } = useSWR('thumbnail-settings', getThumbnailSettings)
  const totalBytes = files.reduce((total, file) => total + file.size_bytes, 0)

  useEffect(() => {
    if (!isDesktop) return
    let disposed = false
    let unlisteners: (() => void)[] = []
    Promise.all([
      listen<ScanProgress>('media-scan-progress', (event) => {
        setScanProgress((current) => ({ ...current, [event.payload.directory_id]: event.payload }))
        if (event.payload.phase !== 'scanning') {
          void refreshFiles()
          void refreshDirectories()
        }
      }),
      listen<ThumbnailProgress>('thumbnail-generation-progress', () => {
        void refreshFiles()
      }),
    ]).then((stopListening) => {
      if (disposed) stopListening.forEach((stop) => stop())
      else {
        unlisteners = stopListening
        void invoke('prepare_thumbnail_cache').catch((error) => setErrorMessage(String(error)))
      }
    }).catch(() => setErrorMessage('Could not listen for library background tasks.'))
    return () => {
      disposed = true
      unlisteners.forEach((stop) => stop())
    }
  }, [isDesktop, refreshFiles, refreshDirectories])

  async function scanDirectory(directory: MediaDirectory) {
    setErrorMessage('')
    setNotice('')
    setScanProgress((current) => ({ ...current, [directory.id]: { directory_id: directory.id, files_found: 0, inaccessible_entries: 0, phase: 'scanning' } }))
    try {
      const result = await invoke<ScanResult>('scan_media_directory', { directoryId: directory.id })
      await Promise.all([refreshFiles(), refreshDirectories()])
      const summary = result.cancelled
        ? 'Scan cancelled. No partial index changes were saved.'
        : `${result.files_indexed} videos indexed${result.renamed_files ? ` · ${result.renamed_files} renamed files matched` : ''}${result.files_removed ? ` · ${result.files_removed} permanently missing` : ''}${result.temporarily_unavailable_files ? ` · ${result.temporarily_unavailable_files} temporarily unavailable` : ''}${result.inaccessible_entries ? ` · ${result.inaccessible_entries} inaccessible locations` : ''}.`
      setNotice(summary)
      setScanProgress((current) => ({ ...current, [directory.id]: { directory_id: directory.id, files_found: result.files_indexed, inaccessible_entries: result.inaccessible_entries, phase: result.cancelled ? 'cancelled' : 'complete' } }))
    } catch (error) {
      await refreshDirectories()
      setScanProgress((current) => ({ ...current, [directory.id]: { directory_id: directory.id, files_found: 0, inaccessible_entries: 0, phase: 'temporarily_unavailable' } }))
      setErrorMessage(typeof error === 'string' ? error : error instanceof Error ? error.message : String(error))
    }
  }

  async function cancelScan(directory: MediaDirectory) {
    try {
      await invoke('cancel_media_scan', { directoryId: directory.id })
    } catch (error) {
      setErrorMessage(typeof error === 'string' ? error : String(error))
    }
  }

  async function refreshThumbnail(media: MediaFile) {
    setErrorMessage('')
    try {
      await invoke('refresh_thumbnail', { mediaFileId: media.id })
      setNotice(`Refreshing thumbnail for ${media.filename}.`)
      await refreshFiles()
    } catch (error) {
      setErrorMessage(typeof error === 'string' ? error : error instanceof Error ? error.message : String(error))
    }
  }

  async function updateThumbnailSettings(update: Partial<ThumbnailSettings>) {
    const next = { ...thumbnailSettings, ...update }
    try {
      await invoke('set_thumbnail_settings', next)
      await Promise.all([refreshThumbnailSettings(), refreshFiles()])
      setNotice('Thumbnail settings saved. The local cache is regenerating in the background.')
    } catch (error) {
      setErrorMessage(typeof error === 'string' ? error : error instanceof Error ? error.message : String(error))
    }
  }

  async function cleanThumbnailCache() {
    try {
      const result = await invoke<CacheCleanupResult>('cleanup_thumbnail_cache')
      setNotice(`Cache cleanup removed ${result.files_removed} files (${formatBytes(result.bytes_removed)}).`)
    } catch (error) {
      setErrorMessage(typeof error === 'string' ? error : error instanceof Error ? error.message : String(error))
    }
  }

  async function addFolders() {
    if (!isDesktop) return
    setIsAdding(true)
    setErrorMessage('')
    setNotice('')
    try {
      const selection = await open({ directory: true, multiple: true, title: 'Choose folders containing videos' })
      if (!selection) return
      const paths = Array.isArray(selection) ? selection : [selection]
      for (const path of paths) {
        const directory = await invoke<MediaDirectory>('add_media_directory', { path })
        await refreshDirectories()
        await scanDirectory(directory)
      }
      await refreshFiles()
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : String(error))
    } finally {
      setIsAdding(false)
    }
  }

  async function removeFolder(directory: MediaDirectory) {
    const confirmed = window.confirm(`Remove this folder from your library?\n\n${directory.path}\n\nYour video files will not be deleted.`)
    if (!confirmed) return
    setErrorMessage('')
    try {
      await invoke('remove_media_directory', { directoryId: directory.id })
      setScanProgress((current) => {
        const next = { ...current }
        delete next[directory.id]
        return next
      })
      await Promise.all([refreshDirectories(), refreshFiles()])
      setNotice('Folder removed from the library. Your files were not changed.')
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : String(error))
    }
  }

  return (
    <section className="media-library-page" aria-labelledby="library-title">
      <header className="library-page-heading">
        <div>
          <div className="section-eyebrow"><span className="eyebrow-line" /> YOUR COLLECTION</div>
          <h1 id="library-title">Media library<span className="title-period">.</span></h1>
          <p>Browse the videos stored on this device.</p>
        </div>
        <button className="button-primary add-folder-button" onClick={addFolders} disabled={!isDesktop || isAdding} title={!isDesktop ? 'Available in the installed Windows desktop app' : undefined}>
          {isAdding ? <LoaderCircle size={17} className="spin-icon" /> : <FolderPlus size={17} />}
          {isAdding ? 'Adding folders…' : 'Add folder'}
        </button>
      </header>

      {!isDesktop && <div className="library-runtime-note"><ShieldCheck size={16} /><span>Folder access and indexing are available in the installed Windows desktop app. This browser preview does not scan or simulate local files.</span></div>}
      {errorMessage && <div className="library-message error" role="alert"><AlertCircle size={16} />{errorMessage}</div>}
      {notice && <div className="library-message success" role="status"><Check size={16} />{notice}</div>}

      <div className="library-stats" aria-label="Library statistics">
        <div><span>VIDEOS</span><strong>{files.length}</strong></div>
        <div><span>FOLDERS</span><strong>{directories.length}</strong></div>
        <div><span>INDEXED SIZE</span><strong>{formatBytes(totalBytes)}</strong></div>
        <div className="scan-state"><span>INDEX STATUS</span><strong><i className={Object.values(scanProgress).some((progress) => progress.phase === 'scanning') ? 'scanning' : ''} />{Object.values(scanProgress).some((progress) => progress.phase === 'scanning') ? 'Scanning folders' : 'Ready'}</strong></div>
      </div>

      <section className="folder-section" aria-labelledby="folders-title">
        <div className="library-subheading"><div><h2 id="folders-title">Library folders</h2><p>Choose which folders are indexed. Removing one never deletes your files.</p></div><span>{directories.length} {directories.length === 1 ? 'FOLDER' : 'FOLDERS'}</span></div>
        {isLoadingDirectories ? <div className="library-loading"><LoaderCircle size={17} className="spin-icon" /> Loading folders…</div> : directories.length ? <div className="library-folder-list">{directories.map((directory) => <FolderRow key={directory.id} directory={directory} progress={scanProgress[directory.id]} onScan={scanDirectory} onCancel={cancelScan} onRemove={removeFolder} />)}</div> : <div className="library-empty-folders"><FolderPlus size={19} /><span>No media folders yet.</span><button onClick={addFolders} disabled={!isDesktop}>Add a folder to begin</button></div>}
      </section>

      <section className="thumbnail-settings" aria-labelledby="thumbnail-settings-title">
        <div className="library-subheading">
          <div><h2 id="thumbnail-settings-title">Thumbnail cache</h2><p>Windows Shell previews are generated in the background and stored separately in LocalAppData.</p></div>
          <button className="folder-action cache-cleanup" onClick={cleanThumbnailCache} disabled={!isDesktop}>Clean unused cache</button>
        </div>
        <div className="thumbnail-settings-controls">
          <label htmlFor="thumbnail-size">Preview size</label>
          <select id="thumbnail-size" value={`${thumbnailSettings.width}x${thumbnailSettings.height}`} onChange={(event) => {
            const [width, height] = event.target.value.split('x').map(Number)
            void updateThumbnailSettings({ width, height })
          }} disabled={!isDesktop}>
            <option value="240x135">Small · 240 × 135</option>
            <option value="320x180">Medium · 320 × 180</option>
            <option value="480x270">Large · 480 × 270</option>
          </select>
          <label htmlFor="thumbnail-quality">JPEG quality</label>
          <select id="thumbnail-quality" value={thumbnailSettings.quality} onChange={(event) => void updateThumbnailSettings({ quality: Number(event.target.value) })} disabled={!isDesktop}>
            <option value="65">Compact · 65%</option>
            <option value="82">Balanced · 82%</option>
            <option value="92">High · 92%</option>
          </select>
        </div>
      </section>

      <section className="video-library-section" aria-labelledby="videos-title">
        <div className="video-library-heading"><div><h2 id="videos-title">All videos</h2><p>{search ? `Search results for “${search}”` : 'Your indexed video collection'}</p></div><div className="library-sort"><label htmlFor="extension-filter">Format</label><select id="extension-filter" value={extension} onChange={(event) => setExtension(event.target.value)}><option value="">All formats</option>{extensions.map((item) => <option key={item} value={item}>{item.toUpperCase()}</option>)}</select><label htmlFor="sort-order">Sort</label><select id="sort-order" value={sortBy} onChange={(event) => setSortBy(event.target.value as SortBy)}><option value="name">Name</option><option value="date">Date added</option><option value="size">File size</option></select></div></div>
        {filesError ? <div className="library-empty-results"><AlertCircle size={20} /><strong>Could not load the library</strong><span>Try reopening the application. Your indexed files are stored on this device.</span></div> : isLoadingFiles ? <div className="library-loading"><LoaderCircle size={17} className="spin-icon" /> Loading videos…</div> : files.length ? <div className="media-grid">{files.map((media) => <MediaCard key={media.id} media={media} onRefresh={refreshThumbnail} />)}</div> : <div className="library-empty-results"><span className="empty-results-icon"><HardDrive size={22} /></span><strong>{search || extension ? 'No matching videos' : 'Your video collection is empty'}</strong><span>{search || extension ? 'Try a different search or format filter.' : 'Add a folder and scan it to see your videos here.'}</span>{!directories.length && <button className="button-primary" onClick={addFolders} disabled={!isDesktop}><FolderPlus size={16} /> Add media folder</button>}</div>}
      </section>
    </section>
  )
}
